import folium
import streamlit as st
from streamlit_folium import st_folium
import pandas as pd

# Función para generar el mapa base
def generar_mapa():
    attr = (
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> '
        'contributors, &copy; <a href="https://cartodb.com/attributions">CartoDB</a>'
    )
    
    tiles = 'https://wms.ign.gob.ar/geoserver/gwc/service/tms/1.0.0/capabaseargenmap@EPSG%3A3857@png/{z}/{x}/{-y}.png'
    
    m = folium.Map(
        location=(-33.457606, -65.346857),
        control_scale=True,
        zoom_start=5,
        tiles=tiles,
        attr=attr
    )
    return m

# Cargar CSV
areas = pd.read_csv('area_protegida.csv')

st.title("Mapa de Áreas Protegidas de Argentina")

mapa = generar_mapa()

# Función para agregar marcadores al mapa
def agregar_marcador(row, color='blue'):
    folium.Marker(
        [row['lat'], row['lng']],
        popup=f"{row['nam']} ({row['objeto']})",
        icon=folium.Icon(color=color)
    ).add_to(mapa)

# Columnas para checkboxes
ac1, ac2 = st.columns([0.3, 0.7])

with ac1:
    mostrar_parque = st.checkbox("Parque Nacional")
    mostrar_reserva = st.checkbox("Reserva Natural")
    mostrar_monumento = st.checkbox("Monumento Natural")

# Filtrado y agregado de marcadores
if mostrar_parque:
    parques = areas[areas['objeto'].str.contains('Parque', case=False, na=False)]
    parques.apply(lambda row: agregar_marcador(row, color='green'), axis=1)

if mostrar_reserva:
    reservas = areas[areas['objeto'].str.contains('Reserva', case=False, na=False)]
    reservas.apply(lambda row: agregar_marcador(row, color='orange'), axis=1)

if mostrar_monumento:
    monumentos = areas[areas['objeto'].str.contains('Monumento', case=False, na=False)]
    monumentos.apply(lambda row: agregar_marcador(row, color='red'), axis=1)

# Mostrar mapa
with ac2:
    st_folium(mapa, key='areas')

