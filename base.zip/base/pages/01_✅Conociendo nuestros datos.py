import pandas as pd
import streamlit as st

# --- Cargar el dataset ---
area = pd.read_csv('area_protegida.csv', encoding='utf-8')

# --- Título y encabezado ---
st.title("Exploración Básica del CSV de Áreas Protegidas")
st.header("Datos encontrados")

# --- 1. Filas y columnas ---
with st.expander("¿Cuántas filas y columnas tiene el dataset?"):
    filas, columnas = area.shape
    st.write(f'Tiene {filas} filas y {columnas} columnas')

# --- 2. Valores únicos de la columna 'nam' ---
if 'nam' in area.columns:
    valores_unicos = area['nam'].unique()
    cant_valores = len(valores_unicos)

    with st.expander("¿Cuántos son los valores únicos de la columna **nam**?"):
        st.write(cant_valores)

    with st.expander("¿Cuáles son los valores únicos de la columna **nam**?"):
        st.write(valores_unicos)
else:
    st.write("No existe la columna 'nam' en el dataset.")

# --- 3. Nombres de las columnas ---
with st.expander("¿Cuáles son los nombres de las columnas?"):
    for col in area.columns:
        st.write(f"- {col}")

# --- 4. Tipos de datos ---
with st.expander("Tipos de datos de cada columna"):
    st.table(area.dtypes.to_frame("Tipo de dato"))


# --- 5. Conteo de categorías (tap) ---
tap_nombres = {
    1: "Reserva",
    2: "Parque",
    3: "Monumento Natural",
    4: "Monumento Histórico",
    5: "Área Natural Protegida Especial"
}

if 'tap' in area.columns:
    area['tap_nombre'] = area['tap'].map(tap_nombres).fillna("Sin categoría")
    with st.expander("Conteo de categorías (tap)"):
        st.table(area['tap_nombre'].value_counts())
else:
    st.write("No existe la columna 'tap' en el dataset.")


# --- 6. Estadísticas de coordenadas ---
if all(col in area.columns for col in ['lat','lng']):
    with st.expander("Estadísticas de latitud y longitud"):
        st.table(area[['lat','lng']].describe())
else:
    st.write("No existen las columnas 'lat' y/o 'lng' en el dataset.")
